LiveOSC
=======

this is an unofficial LiveOSC python script, for the original one visit: http://livecontrol.q3f.org/ableton-liveapi/liveosc/